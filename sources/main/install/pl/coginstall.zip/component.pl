:- module(component, [
      component/1,
      component_name/2,
      component_description/2,
      component_icon/2,
      select_status_html//1,
      select_status/2,
      select_component_request/1
		     ]).

:- use_module(library(http/html_write)).

:- discontiguous component/1,
	component_name/2,
	component_description/2,
	component_depends/2,
	component_icon/2.

:- style_check(-atom).
:- dynamic selected/1.

%
%  Default component selections
%
selected(core).
selected(prolog).
selected(radegast).

% unifies if X is needed by Y
needed_by(X, Y) :-
	component_depends(Y, X),
	selected(Y).
needed_by(X, Y) :-
	component_depends(Y, X),
	needed_by(Y, _).


%
%  select_status(?Name, ?Status)
%  unify if Status is the CSS classname status of
%  component Name
%
select_status(X, needed) :-
	needed_by(X, _).
select_status(X, selected) :-
	\+ needed_by(X, _),
	selected(X).
select_status(_, notselected).

%
% DCG that expands to the English string
% status of this component
%

select_status_html(X) -->
	{needed_by(X, Y),
	 component_name(Y, YName)},
	html(p('Required by ~w'-[YName])).
select_status_html(X) -->
	{ \+ needed_by(X, _),
	  selected(X)},
	html(p('This component will be installed. Click to not install.')).
select_status_html(_) -->
	html(p('Click to install this component')).

select_component_request(Request) :-
	memberchk(path(Path), Request),
	atom_chars(Path, Chars),
	append([/,c,/], ComponentChars, Chars),
	atom_chars(Component, ComponentChars),
	toggle_select(Component).

toggle_select(Component) :-
	selected(Component),
	retractall(selected(Component)),!.

toggle_select(Component) :-
	\+ selected(Component),
	assert(selected(Component)),!.

component(core).
component_name(core, 'Cogbot Core').
component_description(core,
[p('The core of Cogbot. Cogbot Core supports interaction with the bot in the virtual world via botcmd language, or via a telnet or http interface with the headless cogbot process.'),
 p('Almost all users will require this component.'),
 \select_status_html(core)]).

component(prolog).
component_name(prolog, 'SWI-Prolog For Cogbot').
component_description(prolog,
[p([], ['Support for ', a([href='http:swi-prolog.org'], 'swi-prolog'), '.']),
 p([], ['Supports programming the bot via integrated swi-prolog IDE, .pl files, or making prolog queries in world.']),
 p([], ['Many users will want this component, as Prolog is the primary language for programming Cogbot.']),
 \select_status_html(prolog)]).
component_depends(prolog, core).

component(aiml).
component_name(aiml, 'AIMLbot AIML Interpreter').
component_description(aiml,
[p([], ['Programmatic support for an extension of ',
	a([href='http://www.alicebot.org/TR/2005/WD-aiml/'], 'Artificial Intelligence Markup Language')]),
 p([], ['Cogbot AIML is environmentally aware. Patterns can match against conditions in the world, and AIML templates are able to issue botcmd commands.']),
 p([], ['AIMLbot can query an external Cyc Knowledge Server. The Cyc server makes inferences about the bot\'s world.',
 'These in turn can influence pattern matching, so the bot appears aware of it\'s world.']),
 p([], ['AIMLbot can use WordNet (a separate component).']),
 p([], 'AIMLbot includes Lucene, a triple store database. Using Lucene, AIMLbot can persist information without ontologizing it. For example:'),
 ul([], [
     li([], 'User: \"Joe likes sports movies\"'),
     li([], '...(later)...'),
     li([], 'User: \"What does Joe like?\"'),
     li([], 'Bot: \"sports movies\"')]),
 p([], 'Users who want their bots to listen and speak will want this component.'),
 \select_status_html(aiml)
]).
component_depends(aiml, core).
% oh though .. aimlbot need a cyc config url even when cyc client not
% selected  - aimlbot can query ext. server

component(aiml_personality).
component_name(aiml_personality, 'AIML Personality Files').
component_description(aiml_personality,
[p('AIML files for a standard Alice based AIMLbot AIML personality.'),
 p('This personality simulates a westernized, current day adult.'),
 p('AIML users who want bots that emulate humans will want this component.'),
 \select_status_html(aiml_personality)]).
component_depends(aiml_personality, aiml).

component(wordnet).
component_name(wordnet, 'WordNet Lexical Database Support').
component_description(wordnet,
[p(['Improves AIML pattern matching by matching synonyms. So an AIML pattern that contains the word ',
   em([], 'sofa'), ' would match ', em([], 'divan'),
   ' in an utterance.']),
 p('Serious AIMLbot users will want this component.'),
 \select_status_html(wordnet)]).
component_depends(wordnet, aiml).
% TODO include the wordnet license

component(radegast).
component_name(radegast, 'Radegast Viewer').
component_description(radegast,
[p([], 'A version of the Radegast Viewer, integrated with Cogbot.'),
 p([], ['Most bots require some amount of ', &(quot) , 'manual', &(quot),
' driving - for example, to put on a costume before assuming a persona in a role play sim.']),
 p([], 'The Radegast Viewer allows manually controlling the bot. Almost all desktop based Cogbot installs should include Radegast.'),
 \select_status_html(radegast)]).
component_depends(radegast, core).

component(opencyc).
component_name(opencyc, 'OpenCyc Client').
component_description(opencyc,
[p([], 'A client which connects with an external Cyc knowledge server.'),
 p([], 'The integrated client automatically pushes information about the virtual world to the external Cyc database, which can later be queried by the bot or by external programs.'),
 p([], 'Users who wish to use an external Cyc server should install this component.'),
 \select_status_html(opencyc)]).
component_depends(opencyc, core).

component(irc).
component_name(irc, 'Internet Relay Chat Relay').
component_description(irc,
[p([], 'Relays chat between an IRC channel and the bot. Relay allows control of the bot via irc.'),
 p([], 'This is useful for long term monitoring and control of production bots. Users who will be operating an unattended bot should consider using this tool.'),
 \select_status_html(irc)]).
component_depends(irc, core).

component(lisp).
component_name(lisp, 'Common Lisp Interface').
component_description(lisp,
[p('Version of ABCL Common Lisp adapted to control the bot and know about the bot\'s environment.'),
 p('Lisp users will want to install this component.'),
 \select_status_html(lisp)
 ]).
component_depends(lisp, core).

component(sims).
component_name(sims, 'The Sims').
component_description(sims,
[p([
     'The Sims module loops through objects looking for affordances offered by the type system',
     'and ',
     &(quot),
     'uses',
     &(quot),
     'the one that best meets it',
     &(apos),
     's needs.']),
 p('Users who want to use affordances and types based AI should install this component.'),
 p('So should those who just want to see a really cool demo of Cogbot.'),
 \select_status_html(sims)]).
component_depends(sims, core).

component(examples).
component_name(examples, 'Examples').
component_description(examples,
[p('Example files. Examples require various support services depending on the specific example.'),
 p('Users new to Cogbot will appreciate the examples.'),
 \select_status_html(examples)]).

component(docs).
component_name(docs, 'Documentation').
component_description(docs,
[p('User Documentation Bundle.'),
 p('Some day this will be a robot lead series of courses on Cogbot and AI generally,'),
 p(['but for the moment it',
    &(apos),
    's just as likely to be a badly formatted Word doc.']),
 \select_status_html(docs)]).

component(objects).
component_name(objects, 'Cogbot Virtual Objects').
component_description(objects,
[p('Virtual objects for use with Cogbot.'),
 ul([
     li('Tools Cogbot uses for the sim iterator'),
     li('the test suite tools'),
     li('and a cool Cogbot avatar.')]),
 \select_status_html(docs)]).

component_icon(Name, FileName) :-
	atomic_list_concat(['/f/', Name, '.png'], FileName).
