:- module(pages, [
		  wizard_page//0,
		  null_request/1,
		  reset_installer/0,
		  start_seen_request/1,
		  license_accepted_request/1,
		  reset_install_request/1
		 ]).

%
%  Generate the content of the pages for the installer
%  There's only a single handler that displays the page.
%  That page decides what content to display based on the
%  current install state.
%
%  All actions do the actual act, then redirect to the single
%  display page.

:- use_module(library(http/html_write)).
:- use_module(library(http/http_dispatch)).
:- use_module(component).

:-dynamic license_accepted/0,start_seen/0.

:- discontiguous next_wizard_page/2, wizard_page_title/2.
:- discontiguous wizard_page_content/2, wizard_page_actions/2.

%%%%%%%%%%%%%%%
%   template selection
%%%%%%%%%%%%%%%

% pages are built on templates.
% the arg unifies with the current template to use
current_wizard_page(components) :-
	license_accepted.

current_wizard_page(license) :-
	start_seen.

current_wizard_page(start).

reset_installer :-
	retractall(license_accepted),
	retractall(start_seen).

%%%%%%%%%%%%%
%  Requests - verbs that cause actions
%%%%%%%%%%%%%

null_request(_Request).

start_seen_request(_Request) :- start_seen.
start_seen_request(_Request) :-
       assert(start_seen).

license_accepted_request(_Request) :- license_accepted.
license_accepted_request(_Request) :-
	assert(license_accepted).

reset_install_request(_Request) :- reset_installer.

%%%%%%%%%%%%%%%%%%%%
%   Template data
%%%%%%%%%%%%%%%%%%%%
%
%	start
%
wizard_page_title(start, 'Welcome To Cogbot').
wizard_page_content(start, pages:start_page_content).
% not used any more
next_wizard_page(start, license).
wizard_page_actions(start, [\wizard_button(startseen, 'Install Cogbot')]).

start_page_content --> html([
p('If you are seeing this page you have installed swi-prolog correctly.'),
p('This wizard will guide you through the rest of the install.')
       ]).

%
%      license
%
wizard_page_title(license, 'Cogbot New BSD license').
wizard_page_content(license, pages:license_page_content).
next_wizard_page(license, components).
wizard_page_actions(license, [\wizard_button(licenseok, 'I accept the Cogbot New BSD License')]).

license_page_content --> html([
p('Copyright (c) 2012, Logicmoo'),
p('All rights reserved.'),
p('Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:'),
p('Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.'),
p('Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.'),
p('THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.')
       ]).

%
%      components
%
wizard_page_title(components, 'Select Components').
wizard_page_content(components, pages:components_page_content).
next_wizard_page(components, start).
wizard_page_actions(components, [\wizard_button(reset, 'not here yet')]).

components_page_content -->
	{
	    bagof(Name, component(Name), NameList),
	    maplist(component_html , NameList, ComponentHtml)
	},
	html([
    form([], [
	div([id=componentbox], ComponentHtml)
	     ])
       ]).

component_html(X, \component_entry(X)).

component_entry(Name) -->
	{
	    component_name(Name, HumanName),
	    component_description(Name, Description),
	    component_icon(Name, Icon),
	    select_status(Name, Status)
	},
	html([
	    div([
		class='component '+Status,
		cname=Name,
		style='background-image: url(~w)'-[Icon]], [
		    h3([], HumanName),
		    p([], Description)
		])
	     ]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Assemble the actual contents
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wizard_page -->
	{
	    current_wizard_page(Name),
	    wizard_page_title(Name, PageTitle),
	    wizard_page_content(Name, Content),
	    wizard_page_actions(Name, Actions)
	},
	html([
	    h2(PageTitle),
	    \Content,
	    \action_bar(Actions)
        ]).

% action_bar(_) --> [].  % TODO need to fix this

action_bar(Actions) -->
	html([
	  div(id=buttonbar, Actions)
        ]).

/*
wizard_button(prev, Name) -->
	{ next_wizard_page(Prev, Name),
	  ok_to_backtrack_into(Prev)},
	html([
	   div([id=prev, class='wizard button'],
	       [a([href=location_by_id(prev), alt='Previous Page'],
		  'Back')])
	     ]).
*/

wizard_button(Action, Label) -->
	html([
	   div([id=next, class='wizard button'],
	       [a([href=location_by_id(Action), alt=Label],
		  Label)])
	     ]).


