To install Cogbot:

1. unzip the archive containing this README.txt file somewhere
2. Install swi-prolog (tested against 6.1.3) from http://www.swi-prolog.org/
3. Double click coginstall.pl in this directory
4. browse http://127.0.0.1:8080/ with any web browser. Follow directions on the web page.
