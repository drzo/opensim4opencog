:- module(coginstall, [
	start/0,
        autostart/0
]).

%
%  This code after Raivo Laanemet's blog
%

:- use_module(library(http/thread_httpd)).
:- use_module(library(http/http_dispatch)).
:- use_module(library(http/html_write)).
:- use_module(library(http/http_path)).
:- use_module(library(http/http_mime_plugin)).
:- use_module(library(http/http_json)).
:- use_module(library(http/http_server_files)).

% Todo decide what we're really using here
:- use_module(logger).   % the logger, obviously
:- use_module(layout).
:- use_module(pages).
:- use_module(component).

:- dynamic started/0.

server_port(8070).   % change this number to use a different port

% http://www.swi-prolog.org/howto/http/HTTPFile.html

% an image is /f/fluffybunny.png, not /f/img/fluffybunny.png
%
http:location(files_uri, '/static', []).

user:file_search_path(document_root, './files').
% static file handlers. js, images, etc. served from ./f
:- http_handler(root(f), serve_files_in_directory(document_root), [prefix]).

% we have one page that actually displays something
% it figures out what contents to actually display based on
% the currentstate of the install
:- http_handler(root(.) , coginstall:handle_page(
					 'Install Cogbot',
					 pages:null_request,
					 pages:wizard_page),
		[id(start)]).

:- http_handler(root(startseen) , coginstall:redir(
					 start,
					 pages:start_seen_request),
		[id(startseen)]).

:- http_handler(root(licenseok) , coginstall:redir(
					 start,
					 pages:license_accepted_request),
		[id(licenseok)]).

:- http_handler(root(reset) , coginstall:redir(
					 start,
					 pages:reset_install_request),
		[id(reset)]).

:- http_handler(root(c) , coginstall:redir(
					 start,
					 component:select_component_request),
		[id(select), prefix]).

% simple handler used to debug route issues
say_hi(_Request) :-
        format('Content-type: text/plain~n~n'),
        format('Hello World!~n').

start:-
	started,!,
	server_port(Port),
	format(user_error, 'Already running - browse http://127.0.0.1:~w/\n', [Port]).

start:-
	format(user_error, 'Starting Cogbot Installer\n', []),
	server_port(Port),
	http_server(http_dispatch, [port(Port)]),
	assert(started).

%
%  Standard 'wrap and handle' page handler.
%
handle_page(Title, RequestHandler, Child, Request) :-
	call(RequestHandler, Request),
	phrase(html_layout(Title, Child), Html),
%	write(user_error, Html),nl,
        format('Content-type: text/html~n~n'),
	print_html(Html).

redir(Location, RequestHandler, Request) :-
	format(user_error, 'in redir to loc  ~w~n' , [Location]),
	call(RequestHandler, Request),
	http_redirect(moved_temporary, location_by_id(Location), Request).


autostart :-
       start,
       server_port(Port),
       format(string(S), 'http://127.0.0.1:~w/' , [Port]),
       www_open_url(S).

% TODO when it's no longer annoying, call autostart as directive
