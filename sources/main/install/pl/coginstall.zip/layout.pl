:- module(layout, [
	html_layout//2
]).

:- use_module(library(http/html_write)).

%% <module> General installer page layout.


html_layout(Title, Child) -->
	html([\['<!DOCTYPE html>'], html([
		\html_head(Title),
		body([
		    div(id=surround, [
		        div(id=content, [
			    \nav,
			    \Child
			])
		    ])
		])
	])]).

nav --> html([
	    div(id=nav, [
	        ul([], [
		    li([], ['One']),
		    li([], ['Two']),
		    li([], ['Three'])
	        ])
	    ])
       ]).

html_head(Title) -->
	html(head([
		meta(charset = 'UTF-8'),
		title(Title),
		meta([
		     name='Keywords',
		     content='cogbot, virtual robot, opensim, Second Life, virtual world, artificial intelligence, bot'], []),
		meta([
		    name='Description',
		    content='Installer for Cogbot virtual robot'], []),
		link([
			rel = stylesheet,
			type = 'text/css',
			href = 'f/style.css'
		]),
		script(src = 'f/jquery-1.7.1.min.js', []),
		script(src = 'f/components.js', [])
	])).

